//
//  NewSampleBInding.h
//  NewSampleBInding
//
//  Created by BridgeLabz on 26/08/19.
//  Copyright © 2019 BridgeLabz. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NewSampleBInding.
FOUNDATION_EXPORT double NewSampleBIndingVersionNumber;

//! Project version string for NewSampleBInding.
FOUNDATION_EXPORT const unsigned char NewSampleBIndingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NewSampleBInding/PublicHeader.h>


